This Uses python and anybody can use this.

-Note The script does not effect anything thats just the code you can use. You can delete the script if u want to just play
the game.